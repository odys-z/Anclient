﻿1. About

Convert Gltf to Glb, uploadt to jserv sample server.

2. Quick Start

Run Anclient-gltf/file.upload.exe

3. Source

see https://github.com/odys-z/Anclient/exmple.cs/file.upload
