
/** Jsample for EasuUI, function module sys/users.
 * @module jclient.js.jsample.easyui */

/** The function page roles.html is shown int the iframe of app.html,
 * so use this to initialize. */
ssClient = parent.ssClient;

function Workflow () {

}

workflow = new Workflow();
